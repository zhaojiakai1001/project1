#pragma once
#ifndef ENTRY_H
#define ENTRY_H
#include <cstdint>

using namespace std;

struct entry
{
    uint64_t key;
    string val;
    entry(uint64_t _key = 0, string _val = "") {key = _key; val = _val;}
    entry(const entry & other) {key = other.key; val = other.val;}
};
#endif