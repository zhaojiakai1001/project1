#pragma once

#ifndef KVSTORE_H
#define KVSTORE_H
#include "kvstore_api.h"
#include "memtable.h"

using namespace std;

class KVStore : public KVStoreAPI {
	// You can add your implementation here
private:
	memtable memTable;

public:
	KVStore(const std::string &dir);

	~KVStore();

	void put(uint64_t key, const std::string &s) override;

	std::string get(uint64_t key) override;

	bool del(uint64_t key) override;

	void reset() override;

};
#endif
