#pragma once
#ifndef SKIPLIST_H
#define SKIPLIST_H

#include <iostream>
#include <list>
#include <ctime>
#include "entry.h"

#define MIN_GUARD 0ull;
#define MAX_GUARD 18446744073709551615ull;

using namespace std;

struct skiplistnode
{
    entry data;
    short level;
    skiplistnode * next;
    skiplistnode * prev;
    skiplistnode * above;
    skiplistnode * below;
    skiplistnode(entry _data, short _level = 1, skiplistnode * _next = nullptr, skiplistnode * _prev = nullptr, skiplistnode * _above = nullptr, skiplistnode * _below = nullptr) {
        data = _data;
        level = _level;
        next = _next;
        prev = _prev;
        above = _above;
        below = _below;
    }
    skiplistnode(uint64_t _key, string _val = "", short _level = 1, skiplistnode * _next = nullptr, skiplistnode * _prev = nullptr, skiplistnode * _above = nullptr, skiplistnode * _below = nullptr) {
        data.key = _key;
        data.val = _val;
        level = _level;
        next = _next;
        prev = _prev;
        above = _above;
        below = _below;
    }
};

class skiplist
{
private:
    entry leftGuard;
    entry rightGuard;
    skiplistnode * head;
    skiplistnode * tail;
    short level, max_level;
public:
    skiplist(short _max_level);
    ~skiplist();
    short putEntry(const entry _data);
    skiplistnode * searchNode(const uint64_t _key);
    string getVal(const uint64_t _key);
    short delEntry(uint64_t _key);
    void resetSkipList();
};

skiplist::skiplist(short _max_level = 10)
{
    leftGuard = entry(0u, "");
    rightGuard = entry(18446744073709551615u, "");
    head = new skiplistnode(leftGuard);
    tail = new skiplistnode(rightGuard);
    head->next = tail;
    tail->prev = head;
    level = 1;
    max_level = _max_level;
    srand((int)time(0));
}

skiplist::~skiplist()
{
    resetSkipList();
    delete head;
    delete tail;
}

short skiplist::putEntry(const entry _data) {
    skiplistnode * tmp = head;
    short curLevel = 1;
    while (_data.key > tmp->data.key)
    {
        tmp = tmp->next;
    }
    if(_data.key == tmp->data.key) return 0;
    skiplistnode * node = new skiplistnode(_data, curLevel, tmp, tmp->prev);
    tmp->prev->next = node;
    tmp->prev = node;

        skiplistnode * tmpHead = head;
        skiplistnode * tmpTail = tail;
        while(rand() % 2 == 1) {
            if(curLevel == level)
                if(level >= max_level) return 0;
                else {
                    level++;
                    curLevel++;
                    tmpHead->above = new skiplistnode(leftGuard);
                    tmpHead->above->below = tmpHead;
                    tmpHead = tmpHead->above;
                    tmpTail->above = new skiplistnode(rightGuard);
                    tmpTail->above->below = tmpTail;
                    tmpTail = tmpTail->above;
                    node->above = new skiplistnode(_data, curLevel);
                    node->above->below = node;
                    node = node->above;
                    tmpHead->next = node;
                    node->prev = tmpHead;
                    node->next = tmpTail;
                    tmpTail->prev = node;
                }
            else {
                curLevel++;
                tmpHead = tmpHead->above;
                tmp = tmpHead;
                while(_data.key > tmp->data.key) tmp = tmp->next;
                node->above = new skiplistnode(_data, curLevel, tmp, tmp->prev);
                node->above->below = node;
                node = node->above;
                tmp->prev->next = node;
                tmp->prev = node;
            }
        }
    skiplistnode * ttttt = head;
    while(ttttt->next != nullptr) {
        cout << ttttt->data.key << " " << ttttt->data.val << endl;
        ttttt = ttttt->next;
    }
    return curLevel;    
}

skiplistnode * skiplist::searchNode(const uint64_t _key) {
    skiplistnode * tmpHead, *tmpTail;
    tmpHead = head;
    tmpTail = tail;
    while(tmpHead->above) {
        tmpHead = tmpHead->above;
        tmpTail = tmpTail->above;
    }
    while (tmpHead)
    {
        skiplistnode * tmp;
        tmp = tmpHead;
        while (_key > tmp->data.key)
        {
            tmp = tmp->next;
        }
        if(_key == tmp->data.key) return tmp;
        tmpHead = tmpHead->below;
    }
    return nullptr;
}

string skiplist::getVal(const uint64_t _key) {
    skiplistnode * node;
    node = searchNode(_key);
    if(node) return node->data.val;
    cout << "Value not got" << endl;
    return "";
}

short skiplist::delEntry(uint64_t _key) {
    skiplistnode * node;
    short entryLevel = 0;
    short entrySize = 0;
    node = searchNode(_key);
    if(node) {
        entrySize = sizeof(node->data);
        while(node) {
            skiplistnode * tmp;
            tmp = node;
            node->prev->next = node->next;
            node->next->prev = node->prev;
            node = node->below;
            delete tmp;
            entryLevel++;
        }
    }
    return entryLevel * entrySize;
}

void skiplist::resetSkipList() {
    while(head->below != nullptr) {head = head->below;}
    while (tail->below != nullptr){tail = tail->below;}
    
    skiplistnode * tmph = nullptr , * tmpt = nullptr;
    tmph = head;
    tmpt = tail;
    cout << tmph->data.key << " " << tmph->data.val << endl;
    cout << tmpt->data.key << " " << tmpt->data.val << endl;
    cout << head->data.key << " " << head->data.val << endl;
    cout << tail->data.key << " " << tail->data.val << endl;
    while(tmph) {
        cout << "ѭ��1" << endl;
        skiplistnode * tmp = nullptr;
        cout << tmp << endl;
        tmp = tmph->next;
        cout << tmp << endl;
        while(tmp->next != nullptr) {
            cout << "ѭ��1.1" << endl;
            skiplistnode * ttmp;
            ttmp = tmp;
            tmp = tmp->next;
            delete ttmp;
        }
        tmph = tmph->above;
    }
    tmph = head;
    while (tmph->above)
    {
        tmph = tmph->above;
        tmpt = tmpt->above;
    }
    while (tmph->below)
    {
        cout << "ѭ��2" << endl;
        skiplistnode * ttmph = nullptr, * ttmpt = nullptr;
        ttmph = tmph;
        ttmpt = tmpt;
        tmph = tmph->below;
        tmpt = tmpt->below;
        delete ttmph;
        delete ttmpt;
    }
    head->next = tail;
    tail->prev = head;
    return;
}

#endif