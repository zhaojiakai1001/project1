#pragma once
#ifndef MEMTABLE_H
#define MEMTABLE_H
#include <iostream>
#include "skiplist.h"

using namespace std;

#define MAX_SIZE 512 * 4;

class memtable
{
private:
    short size;
    skiplist memList;
public:
    memtable();
    ~memtable(){}
    void putEntry(const entry _data);
    string getVal(const uint64_t _key);
    bool delEntry(uint64_t _key);
    void resetMemtable();
};

memtable::memtable() {
    size = 0;
    memList = skiplist();
}

void memtable::putEntry(const entry _data) {
    short entryNum = memList.putEntry(_data);
    size += sizeof(_data) * entryNum;
    return;
}

string memtable::getVal(const uint64_t _key) {
    return memList.getVal(_key);
}

bool memtable::delEntry(const uint64_t _key) {
    short delSize = memList.delEntry(_key);
    if(delSize == 0) return false;
    size -= delSize;
    return true;
}

void memtable::resetMemtable() {
    memList.resetSkipList();
    size = 0;
    return;
}
#endif